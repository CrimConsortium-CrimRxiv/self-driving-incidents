Self-Driving Incidents Explorer
https://selfdriving.crimconsortium.com/
Data as of 2026-11-22. Codebook version 0.1.

Coded values are machine-drafted and not yet reviewed by a person. See CODEBOOK.md.
Corrections and suggestions: consortium@crimrxiv.com

Data licence: CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/).
Cite as: CrimConsortium. Self-Driving Incidents Explorer [dataset]. https://selfdriving.crimconsortium.com/ (data as of 2026-11-22).
